# Blind handoff

Bạn có 15 phút để đọc guideline và gắn nhãn các ảnh trong `images/`.

1. Tạo CVAT task từ `images/`, dùng raw labels trong `cvat_labels.json`, đặt guideline vào Guide.
2. Không hỏi owner về domain rule; hãy ghi mọi câu hỏi vào clarification log của owner.
3. Export `CVAT for images 1.1`; nếu task dùng track, export `CVAT for video 1.1`.
4. Gửi lại ZIP export cùng câu trả lời cho 5 câu hỏi:
   - Rule nào rõ nhất / giúp quyết định nhanh nhất?: **Ngưỡng kích thước tối thiểu:** Chiều cao của hộp đèn (đo từ mép trên cùng của vỏ/chao đèn đến đáy hộp) phải đạt **từ 10 pixels trở lên** trên ảnh gốc. Đối với đèn bị che khuất một phần, phần vỏ nhìn thấy thực tế vẫn phải đạt chiều cao tối thiểu $\ge$ 10 pixels.
   - Rule nào mơ hồ hoặc phải tự suy diễn?: Đèn quá xa hoặc quá mờ:** Hộp đèn ở hậu cảnh có chiều cao nhỏ hơn 10 pixels hoặc chỉ là đốm sáng nhòe không xác định được cấu trúc vỏ hộp chữ nhật.
   - Sample nào khiến guideline “vỡ”? chưa thấy sample
   - Attribute/default nào trong CVAT dễ gây thao tác sai?: khong co
   - Một thay đổi cụ thể giúp annotator mới ít hỏi hơn?:nên có hình minh họa (Example References)
